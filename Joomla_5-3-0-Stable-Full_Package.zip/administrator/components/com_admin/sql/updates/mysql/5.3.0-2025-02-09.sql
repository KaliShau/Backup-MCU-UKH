ALTER TABLE `#__action_logs_users` DROP COLUMN `exclude_self` /** CAN FAIL **/;
